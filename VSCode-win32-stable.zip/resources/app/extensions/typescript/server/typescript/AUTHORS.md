TypeScript is authored by:

* Adam Freidin
* Ahmad Farid
* Anders Hejlsberg
* Arnav Singh
* Arthur Ozga
* Basarat Ali Syed
* Ben Duffield
* Bill Ticehurst
* Brett Mayen
* Bryan Forbes
* Caitlin Potter
* Chris Bubernak
* Colby Russell
* Colin Snover
* Cyrus Najmabadi
* Dan Quirk
* Daniel Rosenwasser
* David Li
* Denis Nedelyaev
* Dick van den Brink
* Dirk Bäumer
* Eyas Sharaiha
* Frank Wallis
* Gabriel Isenberg
* Gilad Peleg
* Graeme Wicksted
* Guillaume Salles
* Harald Niesche
* Ingvar Stepanyan
* Ivo Gabe de Wolff
* James Whitney
* Jason Freeman
* Jason Ramsay
* Jed Mao
* Johannes Rieken
* John Vilk
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Turner
* Josh Kalderimis
* Julian Williams
* Kagami Sascha Rosylight
* Keith Mashinter
* Ken Howard
* Kenji Imamula
* Lorant Pinter
* Martin Všetička
* Masahiro Wakame
* Max Deepfield
* Micah Zoltu
* Mohamed Hegazy
* Nathan Shively-Sanders
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Paul van Brenk
* Pedro Maltez
* Philip Bulley
* piloopin
* @progre
* Punya Biswal
* Ron Buckton
* Ryan Cavanaugh
* Ryohei Ikegami
* Sébastien Arod
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon Hürlimann
* Solal Pirelli
* Stan Thomas
* Steve Lucco
* Tien Hoanhtien
* Tingan Ho
* togru
* Tomas Grubliauskas
* TruongSinh Tran-Nguyen
* Viliv Vane
* Vladimir Matveev
* Wesley Wigham
* York Yao
* Yui Tanglertsampan
* Zev Spitz
* Zhengbo Li
