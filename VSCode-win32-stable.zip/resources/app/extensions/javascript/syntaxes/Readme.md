The JavaScript.tmLanguage bundle is derived from the TypeScriptReact.tmLanguage.

Changes:
- fileTypes .tsx -> .js
- scopeName scope.tsx -> scope.js
- update language name and file types
